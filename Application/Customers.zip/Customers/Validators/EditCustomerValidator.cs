﻿using Application.Customers.Commands;
using Application.Customers.CustomerDTOs;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Customers.Validators
{
    public class EditCustomerValidator : BaseCustomerValidator<EditCustomer.Command, EditCustomerDto>
    {
        public EditCustomerValidator() : base(x => x.CustomerDto)
        {
            RuleFor(x => x.CustomerDto.Id)
                .NotEmpty().WithMessage("Id is required");
        }
    }
}
