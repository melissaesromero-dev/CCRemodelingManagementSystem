﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Customers.CustomerDTOs
{
    public class EditCustomerDto : BaseCustomerDto
    {
        public string Id { get; set; } = "";
    }
}
