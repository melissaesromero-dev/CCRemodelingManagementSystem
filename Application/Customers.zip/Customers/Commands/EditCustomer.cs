﻿using Application.Core;
using Application.Customers.CustomerDTOs;
using AutoMapper;
using Domain;
using MediatR;
using Persistence;

namespace Application.Customers.Commands
{
    public class EditCustomer
    {
        public class Command : IRequest<Result<Unit>>
        {
            public required EditCustomerDto CustomerDto { get; set; }
        }

        public class Handler(CCRemodelDbContext context, IMapper mapper) : IRequestHandler<Command, Result<Unit>>
        {
            public async Task<Result<Unit>> Handle(Command request, CancellationToken cancellationToken)
            {
                var customer = await context.Customers
                    .FindAsync([request.CustomerDto.Id], cancellationToken);

                if (customer == null) return Result<Unit>.Failure("Customer not found", 404);

                mapper.Map(request.CustomerDto, customer);

                var result = await context.SaveChangesAsync() > 0;

                if (!result) return Result<Unit>.Failure("Failed to update the customer", 400);

                return Result<Unit>.Success(Unit.Value);

            }
        }
    }
}
